import speech_recognition as sr
import pyttsx3

# Инициализация библиотек
recognizer = sr.Recognizer()
tts_engine = pyttsx3.init()

# Функция для синтеза речи
def speak(text):
    tts_engine.say(text)
    tts_engine.runAndWait()

# Функция для распознавания речи
def recognize_speech_from_mic():
    with sr.Microphone() as source:
        print("Слушаю...")
        audio = recognizer.listen(source)
        try:
            text = recognizer.recognize_google(audio, language="ru-RU")
            print(f"Распознано: {text}")
            return text
        except sr.UnknownValueError:
            print("Не удалось распознать речь")
            return None
        except sr.RequestError as e:
            print(f"Ошибка сервиса распознавания речи; {e}")
            return None

# Основной цикл взаимодействия
def main():
    speak("Привет! Я голосовой бот. Скажи что-нибудь.")
    while True:
        text = recognize_speech_from_mic()
        if text:
            if "привет" in text.lower():
                speak("Привет! Как дела?")
            elif "пока" in text.lower():
                speak("До свидания!")
                break
            else:
                speak(f"Вы сказали: {text}")

if __name__ == "__main__":
    main()
